Name 	 Type of pathology	Database	               Name of 	        Start and end 	Sampling frequency
of 							       record in        of selected
record 							       original DB      segment
1	'BII, R'		MIT-BIH Arrhythmia Database	231		[30160,73360]	360
2	'V, B'			MIT-BIH Arrhythmia Database	106		[34920,78120]	360
3	'BIII'			MIT-BIH Arrhythmia Database	107		[266400,309600]	360
4	'A'			MIT-BIH Arrhythmia Database	108		[525600,568800]	360
5	'A, V'			MIT-BIH Arrhythmia Database	118		[486720,529920]	360
6	'NOD, J'		MIT-BIH Arrhythmia Database	124		[104400,147600]	360
7	'AFIB, NOD, J'		MIT-BIH Arrhythmia Database	201		[124200,167400]	360
8	'AFIB, AFL'		MIT-BIH Arrhythmia Database	203		[572400,615600]	360
9	'E, A, SVTA'		MIT-BIH Arrhythmia Database	207		[594000,637200]	360
10	'V, T'			MIT-BIH Arrhythmia Database	208		[414000,457200]	360
11	'SVTA'			MIT-BIH Arrhythmia Database	209		[518400,561600]	360
12	'PREX'			MIT-BIH Arrhythmia Database	230		[108000,151200]	360
13	'BII, R'		MIT-BIH Arrhythmia Database	231		[478800,522000]	360
14	'V, B'			MIT-BIH Arrhythmia Database	233		[201960,245160]	360
15	'J'			MIT-BIH Arrhythmia Database	234		[288360,331560]	360
16	'A'			MIT-BIH Arrhythmia Database	101		[439560,482760]	360
17	'A'			MIT-BIH Arrhythmia Database	112		[248400,291600]	360
18	'A'			MIT-BIH Arrhythmia Database	114		[439560,482760]	360
19	'P, F, V'		MIT-BIH Arrhythmia Database	104		[576000,619200]	360
20	'V'			MIT-BIH Arrhythmia Database	105		[572400,615600]	360
21	'L, V'			MIT-BIH Arrhythmia Database	109		[601200,644400]	360
22	'L, BI'			MIT-BIH Arrhythmia Database	111		[169200,212400]	360
23	'a'			MIT-BIH Arrhythmia Database	113		[478800,522000]	360
24	'NA'			MIT-BIH Arrhythmia Database	115		[541800,585000]	360
25	'V, VP'			MIT-BIH Arrhythmia Database	116		[550800,594000]	360
26	'R, A'			MIT-BIH Arrhythmia Database	118		[478800,522000]	360
27	'V, B, T'		MIT-BIH Arrhythmia Database	119		[97200,140400]	360
28	'A, V'			MIT-BIH Arrhythmia Database	121		[356400,399600]	360
29	'V'			MIT-BIH Arrhythmia Database	123		[540000,583200]	360
30	'P, IVR, T, V, F'	MIT-BIH Arrhythmia Database	124		[367200,410400]	360
31	'V, F, VT'		MIT-BIH Arrhythmia Database	205		[522000,565200]	360
32	'V, F, VT'		MIT-BIH Arrhythmia Database	205		[91440,134640]	360
33	'V, VFL, '		MIT-BIH Arrhythmia Database	207		[55440,98640]	360
34	'R'			MIT-BIH Arrhythmia Database	212		[518400,561600]	360
35	'V, A'			MIT-BIH Arrhythmia Database	213		[529200,572400]	360
36	'V, L'			MIT-BIH Arrhythmia Database	214		[583200,626400]	360
37	'A, FIB'		MIT-BIH Arrhythmia Database	219		[410400,453600]	360
38	'NOD, AFL, A'		MIT-BIH Arrhythmia Database	222		[475200,518400]	360
39	'V, A'			MIT-BIH Supraventricular Arrhythmia Database	801	[26570,41929]	128
40	'V, A'			MIT-BIH Supraventricular Arrhythmia Database	802	[181220,196579]	128
41	'L, A, V'		MIT-BIH Supraventricular Arrhythmia Database	886	[202320,217679]	128
42	'V'			MIT-BIH Supraventricular Arrhythmia Database	851	[150320,165679]	128
43	'A, SVTA'		MIT-BIH Supraventricular Arrhythmia Database	811	[196820,212179]	128
44	'AFIB'			Long Term AF Database		101		[3865673,3881032]	128
45	'AFIB'			Long Term AF Database		120		[321823,337182]	128
46	'AFIB'			Long Term AF Database		55		[10002594,10017953]	128
47	'AFIB'			Long Term AF Database		56		[5229657,5245016]	128
48	'AFIB'			Long Term AF Database		62		[8495932,8511291]	128
49	'AFIB'			Long Term AF Database		102		[10683803,10699162]	128
50	'AFIB'			Long Term AF Database		117		[4050966,4066325]	128


Abb.	Type of patholofy			Number of cases	Name of signals with the pathology
A	Atrial premature beat			14		4,5,9,16,17,18,26,28,35,38,39,40,41,43
AFIB	Atrial fibrillation			9		7,49,50,8,44,45,46,47,48
AFL	Atrial flutter				2		8,38
B	Ventricular bigeminy			3		2,14,27
BI	Atrioventricular block 1st degree	1		22
BII	Atrioventricular block 2nd degree	2		1,13
BIII	Atrioventricular block 3rd degree	1		3
E	Ventricular escape beat			1		9
F	Fusion of ventricular and normal beat	3		30,31,32
IVR	Idioventricular rhythm			1		30
J	Nodal beat				3		6,7,15
L	Left bundle branch block beat		4		21,22,36,41
NA	Sinus arrhythmia			1		24
NOD	Nodal rhythm				3		6,7,15
P	Paced rhythm				2		19,3
PREX	Pre-excitation				1		12
R	Right bundle branch block beat		4		1,13,26,34
SVTA	Supraventricular tachyarrhythmia	3		9,11,43
T	Ventricular trigeminy			2		27,29
V	Ventricular premature beat		20		5,10,14,19,20,21,25,27,28,29,30,31,32,33,35,36,39,40,41,42
VFL	Ventricular flutter			1		33
VP	Ventricular pair			1		25
a	Aberrated atrial premature beat		1		23
